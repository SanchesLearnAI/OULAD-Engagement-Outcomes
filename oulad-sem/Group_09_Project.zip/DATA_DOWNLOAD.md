# Data download

The project uses the public Open University Learning Analytics Dataset (OULAD),
available from UCI:

<https://archive.ics.uci.edu/static/public/349/open+university+learning+analytics+dataset.zip>

```bash
mkdir -p data/raw/oulad
curl -L --fail --retry 3 -o data/raw/oulad/oulad.zip \
  "https://archive.ics.uci.edu/static/public/349/open+university+learning+analytics+dataset.zip"
shasum -a 256 data/raw/oulad/oulad.zip
unzip -o data/raw/oulad/oulad.zip -d data/raw/oulad/
```

The archive holds seven CSVs: `courses`, `assessments`, `vle`, `studentInfo`,
`studentRegistration`, `studentAssessment` and `studentVle`. Keep `oulad.zip`
in `data/raw/oulad/` as well, because S00 records its hash. The audit in this
run recorded:

| File | Rows | SHA-256 |
|---|---:|---|
| courses.csv | 22 | `4f16eee7454b15e109b0a21a0e43be820e6846ed6f9301bb7feb5ab5ad737a75` |
| assessments.csv | 206 | `9ce92381e4a0ac457f8e251b2eb2c179ed51e023ab30d1d671a0268bd62316ba` |
| vle.csv | 6364 | `d7a146497edd0e47ef536144b58796c07b554002d3753e848b8e4cd8a56f4c38` |
| studentInfo.csv | 32593 | `815fbc3e2de29f79900bc63f0345a35db62c9146afaa1d86e7107b8b3beffc60` |
| studentRegistration.csv | 32593 | `bbc87a0de1fe2a9ec6decce1ca6c1a02cf17b54ad3bdcc673fc6413b41c61d47` |
| studentAssessment.csv | 173912 | `b1839e17618a5de36b6d189a242d3123f7939a56c8c9ccef0c17b9199c614a6b` |
| studentVle.csv | 10655280 | `52668253d876c5becbcb72185977152700cecab2942aca807fecc3dd54b937f0` |
